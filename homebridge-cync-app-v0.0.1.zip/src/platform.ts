import { CyncClient } from "./cync/cync-client";

export class CyncAppPlatform {
  private client = new CyncClient(null, null);

  constructor(...) {
    this.log.info("CyncAppPlatform initialized.");
  }

  async configureAccessory(accessory) {
    // no-op until device model implemented
  }

  async didFinishLaunching() {
    this.log.info("Platform ready.");
  }
}
