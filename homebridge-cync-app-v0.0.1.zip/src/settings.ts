export const PLATFORM_NAME = 'CyncAppPlatform';

export const PLUGIN_NAME = 'homebridge-cync-app';
