export class CyncClient {
  constructor(private configClient: any, private tcpClient: any) {}

  async authenticate(username: string, password: string) {}
  async submitTwoFactor(code: string) {}
  async loadConfiguration() {}
  async startTransport(config: any, loginCode: Uint8Array) {}
  async stopTransport() {}
  async setSwitchState(deviceId: string, params: any) {}
}
