export class TcpClient {
  async connect(loginCode: Uint8Array, config: any) {}
  async disconnect() {}

  onDeviceUpdate(cb: any) {}
  onRoomUpdate(cb: any) {}
  onMotionUpdate(cb: any) {}
  onAmbientUpdate(cb: any) {}

  async setSwitchState(deviceId: string, params: any) {}
}
