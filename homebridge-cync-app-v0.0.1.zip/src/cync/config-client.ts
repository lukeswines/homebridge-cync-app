export class ConfigClient {
  async login(username: string, password: string) {}
  async submitTwoFactor(code: string) {}
  async getConfig() {}
}
